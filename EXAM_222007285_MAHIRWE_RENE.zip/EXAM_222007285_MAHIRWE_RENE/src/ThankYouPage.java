/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author murasiralinda
 */
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ThankYouPage extends JFrame {
    
    private JLabel messageLabel;

    public ThankYouPage() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Thank You");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create the JLabel and set its properties
        messageLabel = new JLabel("Login Successfully");
        messageLabel.setHorizontalAlignment(JLabel.CENTER);
        add(messageLabel); // Add the label to the frame
    }
}

